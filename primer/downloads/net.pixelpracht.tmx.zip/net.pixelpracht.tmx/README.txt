A handy Actionscript 3 TMX parser for use with Flixel's FlxTilemap from:
	
	http://pixelpracht.wordpress.com/2010/03/31/flash-tmx-parser/
	
(Shaun Inman commented out some debug trace statements in the original source.)